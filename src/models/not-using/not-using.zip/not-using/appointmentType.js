const { DataTypes } = require('sequelize');
const sequelize = require('../../config/sequelize');

// Define the AppointmentType model
const AppointmentType = sequelize.define(
  'AppointmentType',
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    description: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    tableName: 'appointment_types',
    timestamps: false,
    indexes: [
      {
        unique: true,
        fields: ['name'],
      },
    ],
  },
);

module.exports = AppointmentType;
