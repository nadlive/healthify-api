const { DataTypes } = require('sequelize');
const sequelize = require('../../config/sequelize');

// Define the AppointmentMode model
const AppointmentMode = sequelize.define(
  'AppointmentMode',
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    description: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    tableName: 'appointment_modes',
    timestamps: false,
    indexes: [
      {
        unique: true,
        fields: ['name'],
      },
    ],
  },
);

module.exports = AppointmentMode;
