const prescriptionService = require('../../services/prescriptionService');

const createPrescriptionHandler = async (req, res) => {
  try {
    const {
      appointment_id,
      patient_id,
      provider_id,
      diagnosis,
      symptoms,
      notes,
      valid_until,
      items,
    } = req.body;

    // Validate required fields
    if (
      !appointment_id ||
      !patient_id ||
      !provider_id ||
      !items ||
      items.length === 0
    ) {
      return res.status(400).json({
        success: false,
        message:
          'Missing required fields: appointment_id, patient_id, provider_id, and items are required',
      });
    }

    // Validate items structure
    for (const item of items) {
      if (
        !item.medication_name ||
        !item.dosage_instructions ||
        !item.frequency
      ) {
        return res.status(400).json({
          success: false,
          message:
            'Each item must have medication_name, dosage_instructions, and frequency',
        });
      }
    }

    const prescriptionData = {
      appointment_id,
      patient_id,
      diagnosis,
      symptoms,
      notes,
      valid_until: valid_until ? new Date(valid_until) : null,
    };

    const prescription = await prescriptionService.createPrescription(
      prescriptionData,
      items,
      provider_id,
    );

    res.status(201).json({
      success: true,
      message: 'Prescription created successfully',
      data: prescription,
    });
  } catch (error) {
    console.error('Create prescription error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to create prescription',
    });
  }
};

/**
 * Get prescription by ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const getPrescriptionByIdHandler = async (req, res) => {
  try {
    const { id } = req.params;

    const prescription = await prescriptionService.getPrescriptionById(id);

    res.status(200).json({
      success: true,
      data: prescription,
    });
  } catch (error) {
    console.error('Get prescription error:', error);

    if (error.message.includes('not found')) {
      return res.status(404).json({
        success: false,
        message: error.message,
      });
    }

    res.status(500).json({
      success: false,
      message: error.message || 'Failed to get prescription',
    });
  }
};

/**
 * Get prescriptions by patient ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const getPrescriptionsByPatientHandler = async (req, res) => {
  try {
    const { patientId } = req.params;

    const prescriptions =
      await prescriptionService.getPrescriptionsByPatient(patientId);

    res.status(200).json({
      success: true,
      count: prescriptions.length,
      data: prescriptions,
    });
  } catch (error) {
    console.error('Get patient prescriptions error:', error);

    res.status(500).json({
      success: false,
      message: error.message || 'Failed to get patient prescriptions',
    });
  }
};

/**
 * Get prescriptions by provider ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const getPrescriptionsByProviderHandler = async (req, res) => {
  try {
    const { providerId } = req.params;

    const prescriptions =
      await prescriptionService.getPrescriptionsByProvider(providerId);

    res.status(200).json({
      success: true,
      count: prescriptions.length,
      data: prescriptions,
    });
  } catch (error) {
    console.error('Get provider prescriptions error:', error);

    res.status(500).json({
      success: false,
      message: error.message || 'Failed to get provider prescriptions',
    });
  }
};

/**
 * Update prescription
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const updatePrescriptionHandler = async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;
    const { provider_id } = req.body;

    if (!provider_id) {
      return res.status(400).json({
        success: false,
        message: 'provider_id is required for update',
      });
    }

    // Remove fields that shouldn't be updated
    delete updateData.id;
    delete updateData.prescription_number;
    delete updateData.patient_id;
    delete updateData.appointment_id;
    delete updateData.created_at;
    delete updateData.updated_at;

    const prescription = await prescriptionService.updatePrescription(
      id,
      updateData,
      provider_id,
    );

    res.status(200).json({
      success: true,
      message: 'Prescription updated successfully',
      data: prescription,
    });
  } catch (error) {
    console.error('Update prescription error:', error);

    if (error.message.includes('not found')) {
      return res.status(404).json({
        success: false,
        message: error.message,
      });
    }

    if (error.message.includes('cannot be edited')) {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }

    res.status(500).json({
      success: false,
      message: error.message || 'Failed to update prescription',
    });
  }
};

/**
 * Sign and finalize prescription
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const signPrescriptionHandler = async (req, res) => {
  try {
    const { id } = req.params;
    const { provider_id } = req.body;

    if (!provider_id) {
      return res.status(400).json({
        success: false,
        message: 'provider_id is required for signing',
      });
    }

    const prescription = await prescriptionService.signPrescription(
      id,
      provider_id,
    );

    res.status(200).json({
      success: true,
      message: 'Prescription signed and finalized successfully',
      data: prescription,
    });
  } catch (error) {
    console.error('Sign prescription error:', error);

    if (error.message.includes('not found')) {
      return res.status(404).json({
        success: false,
        message: error.message,
      });
    }

    if (error.message.includes('already signed')) {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }

    res.status(500).json({
      success: false,
      message: error.message || 'Failed to sign prescription',
    });
  }
};

/**
 * Download prescription PDF
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const downloadPrescriptionPDFHandler = async (req, res) => {
  try {
    const { id } = req.params;

    const prescription = await prescriptionService.getPrescriptionById(id);

    if (!prescription.pdf_path) {
      return res.status(404).json({
        success: false,
        message: 'PDF not found for this prescription',
      });
    }

    // Check if file exists
    const fs = require('fs');
    if (!fs.existsSync(prescription.pdf_path)) {
      return res.status(404).json({
        success: false,
        message: 'PDF file not found',
      });
    }

    // Send file
    res.download(
      prescription.pdf_path,
      `prescription_${prescription.prescription_number}.pdf`,
    );
  } catch (error) {
    console.error('Download PDF error:', error);

    if (error.message.includes('not found')) {
      return res.status(404).json({
        success: false,
        message: error.message,
      });
    }

    res.status(500).json({
      success: false,
      message: error.message || 'Failed to download PDF',
    });
  }
};

/**
 * Delete prescription
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const deletePrescriptionHandler = async (req, res) => {
  try {
    const { id } = req.params;
    const { provider_id } = req.body;

    if (!provider_id) {
      return res.status(400).json({
        success: false,
        message: 'provider_id is required for deletion',
      });
    }

    await prescriptionService.deletePrescription(id, provider_id);

    res.status(200).json({
      success: true,
      message: 'Prescription deleted successfully',
    });
  } catch (error) {
    console.error('Delete prescription error:', error);

    if (error.message.includes('not found')) {
      return res.status(404).json({
        success: false,
        message: error.message,
      });
    }

    if (error.message.includes('Cannot delete signed')) {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }

    res.status(500).json({
      success: false,
      message: error.message || 'Failed to delete prescription',
    });
  }
};

/**
 * Get all prescriptions (admin only)
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const getAllPrescriptionsHandler = async (req, res) => {
  try {
    const { Prescription } = require('../../models');
    const prescriptions = await Prescription.findAll({
      include: [
        {
          model: require('../../models').PrescriptionItem,
          as: 'items',
        },
      ],
      order: [['created_at', 'DESC']],
    });

    res.status(200).json({
      success: true,
      count: prescriptions.length,
      data: prescriptions,
    });
  } catch (error) {
    console.error('Get all prescriptions error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to get all prescriptions',
    });
  }
};

module.exports = {
  createPrescription: createPrescriptionHandler,
  getPrescriptionById: getPrescriptionByIdHandler,
  getPrescriptionsByPatient: getPrescriptionsByPatientHandler,
  getPrescriptionsByProvider: getPrescriptionsByProviderHandler,
  updatePrescription: updatePrescriptionHandler,
  signPrescription: signPrescriptionHandler,
  downloadPrescriptionPDF: downloadPrescriptionPDFHandler,
  deletePrescription: deletePrescriptionHandler,
  getAllPrescriptions: getAllPrescriptionsHandler,
};
