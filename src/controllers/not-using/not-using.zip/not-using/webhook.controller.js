const { Transaction, UserSubscription, Invoice } = require('../../models');
const stripeService = require('../../services/stripe.service');
const payhereService = require('../../services/payhere.service');

class WebhookController {
  /**
   * Handle Stripe webhooks
   */
  async handleStripeWebhook(req, res) {
    const signature = req.headers['stripe-signature'];
    const payload = req.body;

    try {
      const event = stripeService.constructWebhookEvent(payload, signature);

      console.log('Stripe webhook received:', event.type);

      switch (event.type) {
        case 'payment_intent.succeeded':
          await this.handleStripePaymentSuccess(event.data.object);
          break;

        case 'payment_intent.payment_failed':
          await this.handleStripePaymentFailed(event.data.object);
          break;

        case 'invoice.paid':
          await this.handleStripeInvoicePaid(event.data.object);
          break;

        case 'invoice.payment_failed':
          await this.handleStripeInvoiceFailed(event.data.object);
          break;

        case 'customer.subscription.updated':
          await this.handleStripeSubscriptionUpdated(event.data.object);
          break;

        case 'customer.subscription.deleted':
          await this.handleStripeSubscriptionDeleted(event.data.object);
          break;

        default:
          console.log(`Unhandled Stripe event type: ${event.type}`);
      }

      res.status(200).json({ received: true });
    } catch (error) {
      console.error('Stripe webhook error:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Handle PayHere webhooks (notify URL)
   */
  async handlePayHereWebhook(req, res) {
    try {
      const notificationData = req.body;

      console.log('PayHere webhook received:', notificationData);

      // Process notification
      const paymentInfo = payhereService.processNotification(notificationData);

      if (!paymentInfo.isValid) {
        return res.status(400).json({ error: 'Invalid notification hash' });
      }

      // Find transaction
      const transaction = await Transaction.findByPk(paymentInfo.orderId);

      if (!transaction) {
        console.error('Transaction not found for order:', paymentInfo.orderId);
        return res.status(404).json({ error: 'Transaction not found' });
      }

      // Update transaction based on status
      const updateData = {
        gatewayTransactionId: paymentInfo.paymentId,
        gatewayResponse: notificationData,
        paymentMethod: paymentInfo.paymentMethod,
      };

      switch (paymentInfo.status) {
        case 'completed':
          updateData.status = 'completed';
          await transaction.update(updateData);

          // If this is for a subscription, activate it
          if (transaction.subscriptionId) {
            const subscription = await UserSubscription.findByPk(
              transaction.subscriptionId,
            );
            if (subscription && subscription.status === 'pending') {
              const plan = await subscription.getPlan();
              const startDate = new Date();
              const endDate = this.calculateEndDate(
                startDate,
                plan.billingPeriod,
              );

              await subscription.update({
                status: 'active',
                startDate,
                endDate,
                nextBillingDate: endDate,
              });
            }
          }

          // Generate invoice
          await this.generateInvoice(transaction);
          break;

        case 'failed':
        case 'cancelled':
          updateData.status = 'failed';
          updateData.failureReason = paymentInfo.statusMessage;
          await transaction.update(updateData);
          break;

        case 'pending':
          updateData.status = 'processing';
          await transaction.update(updateData);
          break;
      }

      res.status(200).send('OK');
    } catch (error) {
      console.error('PayHere webhook error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Stripe event handlers
  async handleStripePaymentSuccess(paymentIntent) {
    const transaction = await Transaction.findOne({
      where: { gatewayTransactionId: paymentIntent.id },
    });

    if (transaction) {
      await transaction.update({
        status: 'completed',
        gatewayResponse: paymentIntent,
      });

      await this.generateInvoice(transaction);
    }
  }

  async handleStripePaymentFailed(paymentIntent) {
    const transaction = await Transaction.findOne({
      where: { gatewayTransactionId: paymentIntent.id },
    });

    if (transaction) {
      await transaction.update({
        status: 'failed',
        failureReason: paymentIntent.last_payment_error?.message,
        gatewayResponse: paymentIntent,
      });
    }
  }

  async handleStripeInvoicePaid(invoice) {
    const subscription = await UserSubscription.findOne({
      where: { stripeSubscriptionId: invoice.subscription },
    });

    if (subscription) {
      await subscription.update({
        status: 'active',
        nextBillingDate: new Date(invoice.period_end * 1000),
      });

      // Create transaction record
      await Transaction.create({
        userId: subscription.userId,
        subscriptionId: subscription.id,
        amount: invoice.amount_paid / 100,
        currency: invoice.currency.toUpperCase(),
        type: 'subscription',
        status: 'completed',
        paymentGateway: 'stripe',
        gatewayTransactionId: invoice.payment_intent,
        gatewayResponse: invoice,
        description: 'Subscription payment',
      });
    }
  }

  async handleStripeInvoiceFailed(invoice) {
    const subscription = await UserSubscription.findOne({
      where: { stripeSubscriptionId: invoice.subscription },
    });

    if (subscription) {
      await subscription.update({ status: 'past_due' });
    }
  }

  async handleStripeSubscriptionUpdated(subscription) {
    const userSubscription = await UserSubscription.findOne({
      where: { stripeSubscriptionId: subscription.id },
    });

    if (userSubscription) {
      const statusMap = {
        active: 'active',
        past_due: 'past_due',
        canceled: 'cancelled',
        unpaid: 'past_due',
      };

      await userSubscription.update({
        status: statusMap[subscription.status] || userSubscription.status,
        nextBillingDate: new Date(subscription.current_period_end * 1000),
      });
    }
  }

  async handleStripeSubscriptionDeleted(subscription) {
    const userSubscription = await UserSubscription.findOne({
      where: { stripeSubscriptionId: subscription.id },
    });

    if (userSubscription) {
      await userSubscription.update({
        status: 'cancelled',
        endDate: new Date(),
      });
    }
  }

  // Helper methods
  async generateInvoice(transaction) {
    // Invoice generation logic here
    // This will be called from invoice controller
    console.log('Invoice generation for transaction:', transaction.id);
  }

  calculateEndDate(startDate, billingPeriod) {
    const date = new Date(startDate);
    switch (billingPeriod) {
      case 'monthly':
        date.setMonth(date.getMonth() + 1);
        break;
      case 'quarterly':
        date.setMonth(date.getMonth() + 3);
        break;
      case 'yearly':
        date.setFullYear(date.getFullYear() + 1);
        break;
    }
    return date;
  }
}

module.exports = new WebhookController();
