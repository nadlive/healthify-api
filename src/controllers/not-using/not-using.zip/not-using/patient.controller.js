const patientService = require('../../services/patient.identity.service');

class PatientController {
  // Create or update patient record
  async createOrUpdatePatient(req, res) {
    try {
      const { userId, ehr_id } = req.body;

      if (!userId) {
        return res.status(400).json({
          success: false,
          message: 'userId is required',
        });
      }

      const patient = await patientService.createOrUpdatePatient(
        userId,
        ehr_id,
      );

      res.status(200).json({
        success: true,
        message: 'Patient record created/updated successfully',
        data: patient,
      });
    } catch (error) {
      console.error('Controller error creating/updating patient:', error);
      res.status(500).json({
        success: false,
        message: 'Error creating/updating patient',
        error: error.message,
      });
    }
  }

  // Get patient by userId
  async getPatientByUserId(req, res) {
    try {
      const { userId } = req.params;
      const patient = await patientService.getPatientByUserId(userId);

      if (!patient) {
        return res.status(404).json({
          success: false,
          message: 'Patient not found',
        });
      }

      res.json({
        success: true,
        data: patient,
      });
    } catch (error) {
      console.error('Controller error getting patient:', error);
      res.status(500).json({
        success: false,
        message: 'Error fetching patient',
        error: error.message,
      });
    }
  }

  // Get patient by ehr_id
  async getPatientByEhrId(req, res) {
    try {
      const { ehrId } = req.params;
      const patient = await patientService.getPatientByEhrId(ehrId);

      if (!patient) {
        return res.status(404).json({
          success: false,
          message: 'Patient not found',
        });
      }

      res.json({
        success: true,
        data: patient,
      });
    } catch (error) {
      console.error('Controller error getting patient:', error);
      res.status(500).json({
        success: false,
        message: 'Error fetching patient',
        error: error.message,
      });
    }
  }
}

module.exports = new PatientController();
