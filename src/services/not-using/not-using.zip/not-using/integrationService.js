const axios = require('axios');

// Configuration for external services
const appointmentServiceUrl =
  process.env.APPOINTMENT_SERVICE_URL || 'http://localhost:5003';
const communicationServiceUrl =
  process.env.COMMUNICATION_SERVICE_URL || 'http://localhost:5004';

// Create Ever Care specific appointments
async function createEverCareAppointment(appointmentData) {
  try {
    const response = await axios.post(
      `${appointmentServiceUrl}/api/appointments`,
      {
        ...appointmentData,
        appointment_type: 'ever_care_consultation',
        appointment_mode: 'video', // Default for Ever Care
        additionalDetails: JSON.stringify({
          program: 'ever_care',
          consultation_type: appointmentData.consultationType || 'weekly',
          ...appointmentData.additionalDetails,
        }),
      },
    );

    return response.data;
  } catch (error) {
    throw new Error(`Failed to create Ever Care appointment: ${error.message}`);
  }
}

// Schedule recurring Ever Care appointments
async function scheduleRecurringAppointments(
  patientId,
  providerId,
  scheduleData,
) {
  try {
    const { frequency, startDate, endDate, consultationType } = scheduleData;
    const appointments = [];

    let currentDate = new Date(startDate);
    const end = new Date(endDate);

    while (currentDate <= end) {
      const appointmentData = {
        patient_id: patientId,
        provider_id: providerId,
        scheduled_time: new Date(currentDate),
        consultationType,
        status: 'Booked',
      };

      const appointment = await createEverCareAppointment(appointmentData);
      appointments.push(appointment);

      // Move to next appointment date based on frequency
      switch (frequency) {
        case 'weekly':
          currentDate.setDate(currentDate.getDate() + 7);
          break;
        case 'biweekly':
          currentDate.setDate(currentDate.getDate() + 14);
          break;
        case 'monthly':
          currentDate.setMonth(currentDate.getMonth() + 1);
          break;
        default:
          currentDate.setDate(currentDate.getDate() + 7);
      }
    }

    return appointments;
  } catch (error) {
    throw new Error(
      `Failed to schedule recurring appointments: ${error.message}`,
    );
  }
}

// Create Ever Care conversation thread
async function createEverCareConversation(conversationData) {
  try {
    const response = await axios.post(
      `${communicationServiceUrl}/api/conversations`,
      {
        ...conversationData,
        conversationType: 'ever-care',
        startedAt: new Date(),
        status: 'active',
      },
    );

    return response.data;
  } catch (error) {
    throw new Error(
      `Failed to create Ever Care conversation: ${error.message}`,
    );
  }
}

// Send Ever Care notifications
async function sendEverCareNotification(notificationData) {
  try {
    const response = await axios.post(
      `${communicationServiceUrl}/api/messages`,
      {
        ...notificationData,
        messageType: 'ever_care_notification',
        priority: notificationData.priority || 'normal',
      },
    );

    return response.data;
  } catch (error) {
    throw new Error(`Failed to send Ever Care notification: ${error.message}`);
  }
}

// Send task reminders
async function sendTaskReminder(patientId, taskData) {
  try {
    const reminderData = {
      conversation_id: taskData.conversation_id,
      sender_id: 'system',
      receiver_id: patientId,
      content: `Reminder: Your task "${taskData.title}" is due on ${new Date(taskData.due_date).toLocaleDateString()}`,
      messageType: 'task_reminder',
      priority: 'high',
    };

    return await sendEverCareNotification(reminderData);
  } catch (error) {
    throw new Error(`Failed to send task reminder: ${error.message}`);
  }
}

// Send goal progress updates
async function sendGoalProgressUpdate(patientId, goalData) {
  try {
    const progressData = {
      conversation_id: goalData.conversation_id,
      sender_id: 'system',
      receiver_id: patientId,
      content: `Great progress! Your goal "${goalData.title}" is now ${goalData.progress_percentage}% complete.`,
      messageType: 'goal_progress',
      priority: 'normal',
    };

    return await sendEverCareNotification(progressData);
  } catch (error) {
    throw new Error(`Failed to send goal progress update: ${error.message}`);
  }
}

// Check service health status
async function checkServiceHealth() {
  try {
    const healthChecks = {
      appointment_service: false,
      communication_service: false,
    };

    try {
      const appointmentResponse = await axios.get(`${appointmentServiceUrl}/`, {
        timeout: 5000,
      });
      healthChecks.appointment_service = appointmentResponse.status === 200;
    } catch (error) {
      console.error('Appointment service health check failed:', error.message);
    }

    try {
      const communicationResponse = await axios.get(
        `${communicationServiceUrl}/`,
        { timeout: 5000 },
      );
      healthChecks.communication_service = communicationResponse.status === 200;
    } catch (error) {
      console.error(
        'Communication service health check failed:',
        error.message,
      );
    }

    return healthChecks;
  } catch (error) {
    throw new Error(`Failed to check service health: ${error.message}`);
  }
}

module.exports = {
  createEverCareAppointment,
  scheduleRecurringAppointments,
  createEverCareConversation,
  sendEverCareNotification,
  sendTaskReminder,
  sendGoalProgressUpdate,
  checkServiceHealth,
};
